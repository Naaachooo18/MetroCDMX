import tkinter as tk
from tkinter import ttk, messagebox
import math
import unicodedata

from Mapa import Mapa
from AEstrella import AEstrella
    
class Placements:# coordenadas base
    BASE_WIDTH = 800
    BASE_HEIGHT = 800

    COORDS_GUI = { #establecemos las coordenadas de cada estación
        # L7 (Naranja)
        "Barranca_del_Muerto_L7": (150, 720), "Mixcoac_L7": (150, 620),
        "San_Antonio_L7": (150, 540), "San_Pedro_de_los_Pinos_L7": (150, 460),
        "Tacubaya_L7": (150, 380), "Constituyentes_L7": (150, 280),
        "Auditorio_L7": (150, 200), "Polanco_L7": (150, 120),
        # L1 (Rosa)
        "Observatorio_L1": (60, 440), "Tacubaya_L1": (150, 380),      
        "Juanacatlan_L1": (230, 320), "Chapultepec_L1": (300, 280),
        "Sevilla_L1": (380, 280), "Insurgentes_L1": (460, 280),
        "Cuauhtemoc_L1": (530, 280), "Balderas_L1": (600, 280),      
        # L9 (Marrón)
        "Tacubaya_L9": (150, 380), "Patriotismo_L9": (260, 380),
        "Chilpancingo_L9": (370, 380), "Centro_Medico_L9": (500, 380), 
        "Lazaro_Cardenas_L9": (620, 380),
        # L3 (Verde)
        "Universidad_L3": (500, 750), "Copilco_L3": (500, 700),
        "Miguel_Angel_de_Quevedo_L3": (500, 650), "Viveros_L3": (500, 600),
        "Coyoacan_L3": (500, 550), "Zapata_L3": (500, 500),        
        "Division_del_Norte_L3": (500, 450), "Eugenia_L3": (500, 415),
        "Etiopia_L3": (500, 400), "Centro_Medico_L3": (500, 380), 
        "Hospital_General_L3": (500, 330), "Ninos_Heroes_L3": (550, 320),  
        "Balderas_L3": (600, 280), "Juarez_L3": (600, 200),
        # L12 (Dorada)
        "Mixcoac_L12": (150, 620), "Insurgentes_Sur_L12": (260, 620),
        "Hospital_20_de_Noviembre_L12": (370, 620), "Zapata_L12": (500, 500),       
        "Parque_de_los_Venados_L12": (600, 540), "Eje_Central_L12": (680, 540),
    }
    #angulos base de las lineas
    LINE_DEFAULT_ANGLES = {"L1": 0, "L3": 0, "L7": 0, "L9": 0, "L12": 0}
    #posición de los nombres
    TEXT_PLACEMENTS = {
        "Barranca del M.": (-18, 0, "e", None), "San Antonio": (-18, 0, "e", None),
        "Constituyentes": (-18, 0, "e", None), "Auditorio": (-18, 0, "e", None), "Polanco": (-18, 0, "e", None),
        "San Pedro": (18, 0, "w", None), 
        "Observatorio": (20, 20, "s", 0), "Juanacatlán": (0, -18, "s", 0),   
        "Chapultepec": (0, -18, "s", 0), "Sevilla": (0, -18, "s", 0),     
        "Insurgentes": (0, 18, "n", 0), "Cuauhtémoc": (0, -18, "s", 0),  
        "Patriotismo": (0, 18, "n", 0), "Chilpancingo": (0, 18, "n", 0), 
        "Lázaro Cárdenas": (0, 18, "n", 0), 
        "Universidad": (18, 0, "w", 0), "Copilco": (18, 0, "w", 0),
        "M.A. Quevedo": (18, 0, "w", 0), "Viveros": (18, 0, "w", 0),
        "Coyoacán": (18, 0, "w", 0), "División del N.": (-18, 0, "e", 0),
        "Eugenia": (-18, 0, "e", 0), "Etiopía": (-18, 0, "e", 0), 
        "Hosp. General": (-18, 0, "e", 0), "Niños Héroes": (18, 0, "w", 0),  
        "Juárez": (0, -18, "s", 0), "Insurgentes Sur": (0, 18, "n", 0), 
        "20 de Nov.": (0, 18, "n", 0), "P. de los Venados": (0, 18, "n", 0), 
        "Eje Central": (0, -25, "n", 0),      
        "Mixcoac": (-18, 0, "e", 0), "Balderas": (18, 0, "w", 0),           
        "Tacubaya": (-18, 0, "e", 0), "Zapata": (-18, 0, "e", 0),            
        "Centro Médico": (47, -10, "s", 0),      
    }
    #posición base
    DEFAULT_PLACEMENT = (18, 0, "w", 0) 

#creamos un tooltip para poder pasar el ratón por un nodo y que nos muestre información
class ToolTip:
    # Constructor de la clase
    def __init__(self, widget):
        self.widget = widget
        self.tipwindow = None
    
    # Calcula la posición del cursor despliega una ventana flotante sin bordes
    def showtip(self, text):
        # Si ya existe un tooltip o el texto está vacío, no hacemos nada
        if self.tipwindow or not text: return
        # Obtenemos coordenadas del mouse en pantalla y sumamos...
        x = self.widget.winfo_pointerx() + 15
        y = self.widget.winfo_pointery() + 10
        # Creamos la ventana secundaria
        self.tipwindow = tw = tk.Toplevel(self.widget)
        # Configuramos el visual de la ventana
        tw.wm_overrideredirect(1) # Elimina bordes y barra de título
        tw.wm_geometry(f"+{x}+{y}") # Posiciona la ventana en las coordenadas calculadas
        # Creamos la etiqueta con el texto y colores oscuros
        label = tk.Label(tw, text=text, justify=tk.LEFT, background="#1F2937", fg="#F3F4F6", relief=tk.SOLID, borderwidth=0, font=("Segoe UI", 9), padx=8, pady=4)
        label.pack()
    
    # Cierra y destruye la ventana del tooltip si está visible
    def hidetip(self):
        # Si la ventana existe en memoria
        if self.tipwindow:
            self.tipwindow.destroy()
            self.tipwindow = None

# --- BUSCADOR INTELIGENTE ---
class BuscadorInteligente(tk.Frame):
    # Inicializa el widget, configura el campo de entrada y vincula los eventos de teclado y foco
    def __init__(self, parent, lista_completa, font=("Segoe UI", 11), **kwargs):
        super().__init__(parent, **kwargs) # bases de datos de estaciones
        self.lista_completa = lista_completa
        #Variable de control para el texto
        self.var = tk.StringVar()
        # Configuración visual del campo de texto
        self.entry = tk.Entry(self, textvariable=self.var, font=font, relief="flat", bg="#334155", fg="white", insertbackground="white")
        self.entry.pack(fill=tk.X, ipady=8, padx=10)
        # Vinculación de eventos
        self.entry.bind('<KeyRelease>', self.on_keyrelease)
        self.entry.bind('<FocusOut>', self.on_focus_out)
        self.entry.bind('<Down>', self.mover_abajo)
        self.entry.bind('<Up>', self.mover_arriba)
        self.entry.bind('<Return>', self.seleccionar_tecla)
        self.listbox_window = None
    
    # Elimina acentos y convierte a minúsculas para facilitar la búsqueda
    def _normalizar(self, texto: str) -> str:
        if texto is None: return ""
        nf = unicodedata.normalize('NFD', texto)
        return ''.join(ch for ch in nf if unicodedata.category(ch) != 'Mn').lower()
    
    # Filtra la lista de opciones basándose en el texto escrito por el usuario.
    def on_keyrelease(self, event):
        # Ignoramos teclas de navegación para no re-filtrar innecesariamente
        if event.keysym in ('Up', 'Down', 'Return', 'Tab', 'Left', 'Right'): return
        valor = self.var.get()
        # Si el campo está vacío, escondemos la lista
        if valor == '': self.ocultar_lista()
        else:
            # Normalizamos lo escrito y filtramos la lista completa
            valor_norm = self._normalizar(valor)
            filtrada = [item for item in self.lista_completa if valor_norm in self._normalizar(item)]
            # Mostramos los resultados
            self.mostrar_lista(filtrada)
    
    # Muestra o actualiza la ventana flotante con las sugerencias filtradas debajo
    def mostrar_lista(self, items):
        # Si no hay coincidencias, cerrar lista
        if not items:
            self.ocultar_lista()
            return
        # Si la ventana no existe, la creamos desde cero
        if not self.listbox_window:
            self.listbox_window = tk.Toplevel(self)
            self.listbox_window.wm_overrideredirect(True) #Sin bordes
            self.listbox_window.wm_attributes("-topmost", True) # Siempre encima
            # Creamos el Listbox dentro de la ventana flotante
            self.listbox = tk.Listbox(self.listbox_window, font=("Segoe UI", 10), bg="#1E293B", fg="white", selectbackground="#2563EB", relief="flat", borderwidth=0, height=5)
            self.listbox.pack(fill=tk.BOTH, expand=True)
            self.listbox.bind('<<ListboxSelect>>', self.on_select_click)
        # Limpiamos la lista anterior y llenamos con la nueva filtrada
        self.listbox.delete(0, tk.END)
        for item in items: self.listbox.insert(tk.END, item)
        # Calculamos posición exacta debajo del Entry
        x = self.entry.winfo_rootx()
        y = self.entry.winfo_rooty() + self.entry.winfo_height()
        w = self.entry.winfo_width()
        self.listbox_window.wm_geometry(f"{w}x{150}+{x}+{y}")
    
    # Cierra la ventana de sugerencias si está abierta
    def ocultar_lista(self):
        if self.listbox_window:
            self.listbox_window.destroy()
            self.listbox_window = None
    
    # Maneja la selección de un elemento mediante clic del ratón
    def on_select_click(self, event):
        # Verifica que haya algo seleccionado realmente
        if not self.listbox.curselection(): return
        # Obtiene el texto y lo establece en el input
        self.set_value(self.listbox.get(self.listbox.curselection()[0]))
    
    # Maneja la selección de un elemento mediante la tecla Enter
    def seleccionar_tecla(self, event):
        if self.listbox_window and self.listbox.curselection():
            self.set_value(self.listbox.get(self.listbox.curselection()[0]))
    
    # Establece el valor seleccionado en el campo de entrada y cierra la lista
    def set_value(self, valor):
        self.var.set(valor)# Pone el texto en el Entry
        self.entry.icursor(tk.END) # Mueve el cursor de escritura al final
        self.ocultar_lista() # Cierra sugerencias
        
    # Retorna el texto actual del campo de entrada
    def get(self):
        return self.var.get()
    
    # Transfieren el foco a la lista para permitir la navegación con las flechas
    def mover_abajo(self, event):
        if self.listbox_window:
            self.listbox.focus_set() # Pone el foco en la lista
            self.listbox.selection_set(0)#  Selecciona el primer elemento

    def mover_arriba(self, event):
        if self.listbox_window:
            self.listbox.focus_set()
            self.listbox.selection_set(0)
    
    # Gestionan el cierre de la lista cuando el usuario hace clic fuera del widget
    def on_focus_out(self, event):
        self.after(200, self.check_focus)

    def check_focus(self):
        try:
            focus = self.focus_get()
            if focus != self.listbox and focus != self.entry: self.ocultar_lista()
        except: pass
    
    # Actualiza la configuración de colores del widget
    def actualizar_colores(self, bg_input, fg_input, bg_panel=None):
        self.entry.config(bg=bg_input, fg=fg_input, insertbackground=fg_input)
        if bg_panel: self.config(bg=bg_panel)
        if self.listbox_window: self.listbox.config(bg="#1E293B", fg="white")


class Boton(tk.Canvas):
    # Inicializa el lienzo, dibuja la forma redondeada y el texto, y vincula los eventos del ratón
    def __init__(self, parent, text, command, width=200, height=50, bg_color="#2563EB", text_color="white", hover_color="#1D4ED8"):
        super().__init__(parent, width=width, height=height, bg=parent['bg'], highlightthickness=0)
        self.command = command
        self.bg_color = bg_color
        self.hover_color = hover_color
        self.rect = self.create_rounded_rect(2, 2, width-2, height-2, 20, fill=bg_color, outline="")
        self.texto = self.create_text(width/2, height/2, text=text, fill=text_color, font=("Segoe UI", 11, "bold"))
        self.bind("<Enter>", self.on_enter)
        self.bind("<Leave>", self.on_leave)
        self.bind("<Button-1>", self.on_click)
    
    # Dibuja un polígono que simula un rectángulo con esquinas redondeadas
    def create_rounded_rect(self, x1, y1, x2, y2, r, **kwargs):
        points = (x1+r, y1, x1+r, y1, x2-r, y1, x2-r, y1, x2, y1, x2, y1+r, x2, y1+r, x2, y2-r, x2, y2-r, x2, y2, x2-r, y2, x2-r, y2, x1+r, y2, x1+r, y2, x1, y2, x1, y2-r, x1, y2-r, x1, y1+r, x1, y1+r, x1, y1)
        return self.create_polygon(points, **kwargs, smooth=True)
    
    # Cambia el color y el ratón cuando entra en el botón (hover)
    def on_enter(self, e):
        self.itemconfig(self.rect, fill=self.hover_color)
        self.config(cursor="hand2")
    
    # Restaura el ratón y el color del botón
    def on_leave(self, e):
        self.itemconfig(self.rect, fill=self.bg_color)
    
    # Ejecuta la función asignada cuando se hace clic en el botón
    def on_click(self, e):
        if self.command: self.command()
   
    # Actualiza los colores del botón y del fondo
    def update_colors(self, parent_bg, btn_bg, btn_hover):
        self.config(bg=parent_bg)
        self.bg_color = btn_bg
        self.hover_color = btn_hover
        self.itemconfig(self.rect, fill=btn_bg)

# --- INTERFAZ PRINCIPAL ---
class InterfazMetro2025:
    # Inicializa la ventana, carga la lógica del mapa y prepara los diccionarios y estilos visuales
    def __init__(self, root):
        self.root = root
        self.root.title("Metro CDMX • Navigator 2025")
        self.root.geometry("1280x850")
        
        self.style = ttk.Style()
        self.style.theme_use('clam') 
        
        self.mapa_logico = Mapa()
        self.buscador = AEstrella(self.mapa_logico)
        
        self.hora_punta_var = tk.BooleanVar()
        self.hora_punta_var.set(False)

        self.colores = {
            "bg_app": "#0F172A", "bg_panel": "#1E293B", "text_primary": "#F8FAFC", "text_secondary": "#94A3B8", 
            "map_bg": "#0F172A", "line_inactive": "#334155", "node_fill": "#1E293B", "node_outline": "#94A3B8", "text_map": "#CBD5E1"
        }
        self.lineas_color = { "L1": "#EC4899", "L3": "#84CC16", "L7": "#F97316", "L9": "#A97142", "L12": "#EAB308" }
        self.info_lineas = { "L1": "Línea 1", "L3": "Línea 3", "L7": "Línea 7", "L9": "Línea 9", "L12": "Línea 12" }

        self.nombres_mapa = {
            "Barranca_del_Muerto_L7": "Barranca del M.", "Mixcoac_L7": "Mixcoac",
            "San_Antonio_L7": "San Antonio", "San_Pedro_de_los_Pinos_L7": "San Pedro", 
            "Tacubaya_L7": "Tacubaya", "Constituyentes_L7": "Constituyentes",
            "Auditorio_L7": "Auditorio", "Polanco_L7": "Polanco",
            "Observatorio_L1": "Observatorio", "Tacubaya_L1": "Tacubaya",
            "Juanacatlan_L1": "Juanacatlán", "Chapultepec_L1": "Chapultepec",
            "Sevilla_L1": "Sevilla", "Insurgentes_L1": "Insurgentes",
            "Cuauhtemoc_L1": "Cuauhtémoc", "Balderas_L1": "Balderas",
            "Tacubaya_L9": "Tacubaya", "Patriotismo_L9": "Patriotismo",
            "Chilpancingo_L9": "Chilpancingo", "Centro_Medico_L9": "Centro Médico",
            "Lazaro_Cardenas_L9": "Lázaro Cárdenas", "Universidad_L3": "Universidad", 
            "Copilco_L3": "Copilco", "Miguel_Angel_de_Quevedo_L3": "M.A. Quevedo", 
            "Viveros_L3": "Viveros", "Coyoacan_L3": "Coyoacán", "Zapata_L3": "Zapata",
            "Division_del_Norte_L3": "División del N.", "Eugenia_L3": "Eugenia",
            "Etiopia_L3": "Etiopía", "Centro_Medico_L3": "Centro Médico",
            "Hospital_General_L3": "Hosp. General", "Ninos_Heroes_L3": "Niños Héroes",          
            "Balderas_L3": "Balderas", "Juarez_L3": "Juárez",
            "Mixcoac_L12": "Mixcoac", "Insurgentes_Sur_L12": "Insurgentes Sur",
            "Hospital_20_de_Noviembre_L12": "20 de Nov.", "Zapata_L12": "Zapata",
            "Parque_de_los_Venados_L12": "P. de los Venados", "Eje_Central_L12": "Eje Central" 
        }

        self.mapa_nombres_reales = {} 
        for nodo in self.mapa_logico.get_grafo().nodes():
            nombre_bonito = self.nombres_mapa.get(nodo, nodo.split('_')[0])
            if nombre_bonito not in self.mapa_nombres_reales:
                self.mapa_nombres_reales[nombre_bonito] = []
            self.mapa_nombres_reales[nombre_bonito].append(nodo)
        self.lista_estaciones = sorted(list(self.mapa_nombres_reales.keys()))

        self.terminales = {
            "L1": {"izq": "Observatorio", "der": "Balderas"}, "L3": {"arriba": "Juárez", "abajo": "Universidad"},
            "L7": {"arriba": "Polanco", "abajo": "Barranca del Muerto"}, "L9": {"izq": "Tacubaya", "der": "Lázaro Cárdenas"},
            "L12": {"izq": "Mixcoac", "der": "Eje Central"}
        }

        self.crear_layout()
        self.aplicar_tema_fijo()
    
    # Divide la ventana en panel lateral con los conotroles y el mapa
    def crear_layout(self):
        #contenedor principal (ocupa toda la pantalla)
        self.main_container = tk.Frame(self.root)
        self.main_container.pack(fill=tk.BOTH, expand=True)
        #crea el panel izquierdo
        self.sidebar = tk.Frame(self.main_container, width=400, padx=30, pady=30)
        self.sidebar.pack(side=tk.LEFT, fill=tk.Y)
        #evito que si meto cosas cambie el tamaño
        self.sidebar.pack_propagate(False)

        #Titulo(CDMx Metro)
        self.lbl_logo = tk.Label(self.sidebar, text="CDMX Metro", font=("Segoe UI Variable Display", 28, "bold"), anchor="w")
        self.lbl_logo.pack(fill=tk.X)
        #Subtitulo
        self.lbl_sublogo = tk.Label(self.sidebar, text="Aplicación Metro CDMX", font=("Segoe UI", 11), anchor="w")
        self.lbl_sublogo.pack(fill=tk.X, pady=(0, 40))
        #1er cuadro de busqueda
        self.crear_buscador("Punto de Partida", "origen")
        #2do cuadro de busqueda
        self.crear_buscador("Destino Final", "destino", padding=(20, 0))

        #boton de hora punta
        self.chk_hora_punta = tk.Checkbutton(self.sidebar, text=" Hora Punta ⚠️", variable=self.hora_punta_var,
                                             relief="flat", cursor="hand2", font=("Segoe UI", 10, "bold"),
                                             highlightthickness=0, borderwidth=0, activebackground=self.sidebar['bg'], activeforeground="#EF4444")
        self.chk_hora_punta.pack(anchor="w", pady=(30, 10))

        #botón calcular ruta óptima
        self.btn_calc = Boton(self.sidebar, "Calcular Ruta Óptima", self.calcular_ruta, width=340, height=55)
        self.btn_calc.pack(pady=(0, 30))

        #titulo detalles del viaje
        self.lbl_res_titulo = tk.Label(self.sidebar, text="Detalles del viaje", font=("Segoe UI", 12, "bold"), anchor="w")
        self.lbl_res_titulo.pack(fill=tk.X, pady=(0, 10))

        #caja donde se muestran los detalles de la ruta
        self.txt_pasos = tk.Text(self.sidebar, height=15, font=("Segoe UI", 10), relief="flat", wrap="word", padx=15, pady=15, highlightthickness=0, state="disabled")
        self.txt_pasos.pack(fill=tk.BOTH, expand=True)
        #configura las negritas, los colores...
        self.configurar_tags_texto()

        #caja que contiene el mapa(canvas)
        self.map_frame = tk.Frame(self.main_container)
        self.map_frame.pack(side=tk.RIGHT, fill=tk.BOTH, expand=True)
        #canvas donde se dibuja el mapa 
        self.canvas = tk.Canvas(self.map_frame, highlightthickness=0)
        self.canvas.pack(fill=tk.BOTH, expand=True) 
        #redibuja el mapa cuando cambia de tamaño
        self.canvas.bind("<Configure>", self.redimensionar_mapa)

    # Método auxiliar para instanciar los widgets de la búsqueda y evitar la duplicidad del código
    def crear_buscador(self, titulo, var_name, padding=(0, 0)):
        lbl = tk.Label(self.sidebar, text=titulo, font=("Segoe UI", 10, "bold"), anchor="w")
        lbl.pack(fill=tk.X, pady=(padding[0], 8)) 
        if var_name == "origen": self.lbl_origen = lbl
        else: self.lbl_destino = lbl

        cb = BuscadorInteligente(self.sidebar, self.lista_estaciones, bg="#1E293B")
        cb.pack(fill=tk.X, pady=(0, padding[1])) 
        if var_name == "origen": self.combo_origen = cb
        else: self.combo_destino = cb
    
    # Define los estilos de formato para el texto de la ruta
    def configurar_tags_texto(self):
        self.txt_pasos.tag_config("titulo", font=("Segoe UI", 11, "bold"))
        self.txt_pasos.tag_config("meta", foreground="#888")
        self.txt_pasos.tag_config("direccion", foreground="#2563EB", font=("Segoe UI", 10, "bold"))
        self.txt_pasos.tag_config("transbordo", foreground="#EF4444", font=("Segoe UI", 10, "bold"))
        self.txt_pasos.tag_config("pasos", lmargin1=15, lmargin2=15)
        self.txt_pasos.tag_config("alerta", foreground="#EF4444", font=("Segoe UI", 10, "italic"))
    
    # Aplica la misma paleta de colores a todos los elementos
    def aplicar_tema_fijo(self):
        t = self.colores
        self.root.config(bg=t["bg_app"])
        self.main_container.config(bg=t["bg_app"])
        self.sidebar.config(bg=t["bg_panel"])
        self.map_frame.config(bg=t["map_bg"])
        self.canvas.config(bg=t["map_bg"])
        
        for l in [self.lbl_logo, self.lbl_res_titulo]: l.config(bg=t["bg_panel"], fg=t["text_primary"])
        for l in [self.lbl_sublogo, self.lbl_origen, self.lbl_destino]: l.config(bg=t["bg_panel"], fg=t["text_secondary"])
        
        self.txt_pasos.config(bg=t["bg_app"], fg=t["text_primary"])
        self.chk_hora_punta.config(bg=t["bg_panel"], fg=t["text_primary"], selectcolor=t["bg_panel"], activebackground=t["bg_panel"])

        self.combo_origen.actualizar_colores("#334155", "white", t["bg_panel"])
        self.combo_destino.actualizar_colores("#334155", "white", t["bg_panel"])
        self.btn_calc.update_colors(t["bg_panel"], "#818CF8", "#6366F1")
        self.dibujar_mapa()

    # Cambia el tamaño del mapa cuando reajustas el tamaño de la ventana
    def redimensionar_mapa(self, event):
        self.dibujar_mapa()

    # Calcula la escala y el centrado para ajustar las coordenadas al tamaño actual del canvas
    def obtener_transformacion(self):
        #obtengo el ancho y largo del canvas
        w_actual = self.canvas.winfo_width()
        h_actual = self.canvas.winfo_height()
        #si es muy pequeño, hace la transformación por defecto
        if w_actual < 50 or h_actual < 50: return 1, 0, 0
        
        #obtiene las coordenadas originales de las estaciones
        all_coords = list(Placements.COORDS_GUI.values())
        xs = [c[0] for c in all_coords]
        ys = [c[1] for c in all_coords]
        #calcula los límites máximos y mínimos 
        min_x, max_x = min(xs), max(xs)
        min_y, max_y = min(ys), max(ys)

        #calculo el ancho y largo del contenido del mapa
        content_w = max_x - min_x
        content_h = max_y - min_y
        #hago un margen(para que no quede pegado a los bordes)
        margin = 100
        
        #ajusta el mapa al canvas
        scale_x = (w_actual - margin) / content_w
        scale_y = (h_actual - margin) / content_h
        #seleccionamos el menor para asegurarnos que quede dentro del canvas
        scale = min(scale_x, scale_y)

        #calculamos las dimensiones que ocupara el mapa
        visual_w = content_w * scale
        visual_h = content_h * scale
        #calcula el desplazamiento para centrar el mapa
        offset_x = (w_actual - visual_w) / 2
        offset_y = (h_actual - visual_h) / 2
        #obtiene los desplazamientos con la coordenada mínima()para que este alineado
        dx = offset_x - (min_x * scale)
        dy = offset_y - (min_y * scale)
        #devuelve la escala y los desplazamientos para dibujar
        return scale, dx, dy
    
    #dibuja las nodos y las aristas en el canvas
    def dibujar_mapa(self):
        self.canvas.delete("all") #borra el dibujo anterior
        t = self.colores
        grafo = self.mapa_logico.get_grafo()
        scale, dx, dy = self.obtener_transformacion()
        drawn_names = set()
        #dibuja las aristas
        for u, v in grafo.edges():
            #solo dibuja si tienen coordenadas asignadas
            if u in Placements.COORDS_GUI and v in Placements.COORDS_GUI:
                x1_b, y1_b = Placements.COORDS_GUI[u]
                x2_b, y2_b = Placements.COORDS_GUI[v]
                x1 = x1_b * scale + dx
                y1 = y1_b * scale + dy
                x2 = x2_b * scale + dx
                y2 = y2_b * scale + dy

                linea_u = u.split('_')[-1]
                linea_v = v.split('_')[-1]
                #comprueba que las estaciones pertenezacan a la misma arista y pinta la linea
                if linea_u == linea_v:
                    color = self.lineas_color.get(linea_u, "#999")
                    w = 6 * scale
                else:
                    color = t["line_inactive"]
                    w = 3 * scale
                    #dibuja la linea en el canvas
                self.canvas.create_line(x1, y1, x2, y2, fill=color, width=w, capstyle=tk.ROUND, tags="mapa")
        #dibujo los nodos
        r = 7 * scale
        font_size = int(8 * scale)
        font_size = max(6, min(font_size, 12)) 

        for nodo in grafo.nodes():
            if nodo in Placements.COORDS_GUI:
                x_b, y_b = Placements.COORDS_GUI[nodo]
                x = x_b * scale + dx
                y = y_b * scale + dy
                #obtiene el nombre
                nombre = self.nombres_mapa.get(nodo, nodo.split('_')[0])
                linea = nodo.split('_')[-1]
                #dibuja el circulo exterior del nodo
                self.canvas.create_oval(x-(r+2), y-(r+2), x+(r+2), y+(r+2), fill=t["map_bg"], outline="", tags="mapa")
                #dibuja el interior del circulo
                item_id = self.canvas.create_oval(x-r, y-r, x+r, y+r, fill=t["node_fill"], outline=t["node_outline"], width=1.5*scale, tags=("nodo", nodo))
                
                #dibuja el nombre
                if nombre not in drawn_names:
                    #busca la posición del nombre
                    placement = Placements.TEXT_PLACEMENTS.get(nombre)
                    if placement:
                        off_x, off_y, anchor, ang = placement
                    else:
                        off_x, off_y, anchor, ang = Placements.DEFAULT_PLACEMENT
                    #si no tiene ángulo coge el mismo que la linea
                    if ang is None: ang = Placements.LINE_DEFAULT_ANGLES.get(linea, 0)
                    
                    #posición del nombre
                    t_x = x + (off_x * scale)
                    t_y = y + (off_y * scale)
                    
                    #ponemos negrita al nombre
                    self.canvas.create_text(t_x, t_y, text=nombre, anchor=anchor, font=("Segoe UI", font_size, "bold"), fill=t["map_bg"], width=150, angle=ang)
                    #texto real
                    self.canvas.create_text(t_x, t_y, text=nombre, anchor=anchor, font=("Segoe UI", font_size, "bold"), fill=t["text_map"], tags=("texto", nodo), angle=ang)
                    drawn_names.add(nombre)
                #muestra el tooltip cuando se pone el cursor sobre el nodo
                self.canvas.tag_bind(item_id, "<Enter>", lambda e, n=nodo, i=item_id: self.on_hover_enter(e, n, i))
                #oculta el tooltip cuando el cursor sale del nodo
                self.canvas.tag_bind(item_id, "<Leave>", lambda e, i=item_id: self.on_hover_leave(e, i))
    
    #resalta el nodo cuando el cursor está encima del nodo 
    def on_hover_enter(self, event, nodo_id, item_id):
        self.canvas.itemconfig(item_id, width=3, outline=self.colores["text_primary"])
        #obtiene el nombre de la estación
        nombre = self.nombres_mapa.get(nodo_id, nodo_id.split('_')[0])
        linea = nodo_id.split('_')[-1]
        #construye el texot que aparece en el tooltip(nombre de la estación y linea)
        info = f"{nombre}\n{self.info_lineas.get(linea, linea)}"
        #asocia el tooltip con el canvas
        self.tooltip = ToolTip(self.canvas)
        #muestra el tooltip 
        self.tooltip.showtip(info)
    
    #cuando el cursor abandona el nodo, este vuelve a su estado original
    def on_hover_leave(self, event, item_id):
        t = self.colores
        self.canvas.itemconfig(item_id, width=1.5, outline=t["node_outline"])
        #si el tooltip esta activado lo oculta
        if hasattr(self, 'tooltip'): self.tooltip.hidetip()


    def get_direccion_linea(self, u, v, linea):
           #si la estación no tiene coordenadas, no se puede calcular
        if u not in Placements.COORDS_GUI or v not in Placements.COORDS_GUI: return ""
        #si la linea no tiene terminales no se puede saber la dirección
        if linea not in self.terminales: return ""
        #coordenadas de la estación actual y la siguiente
        xu, yu = Placements.COORDS_GUI[u]
        xv, yv = Placements.COORDS_GUI[v]
        #ver hacia donde se mueve el tren(movimiento horizontal y vertical)
        dx = xv - xu
        dy = yv - yu
        #obtener las terminales
        terms = self.terminales[linea]
        #desplazamientos orizontales y verticales   
        if linea in ["L1", "L9", "L12"]: return terms["der"] if dx > 0 else terms["izq"]
        elif linea in ["L3", "L7"]: return terms["abajo"] if dy > 0 else terms["arriba"]
        return ""

    #obtiene los nodos internos de una estación
    def obtener_mejor_nodo(self, nombre_origen, nombre_destino):
        #obtiene nodos origen y destino
        candidatos_origen = self.mapa_nombres_reales.get(nombre_origen)
        candidatos_destino = self.mapa_nombres_reales.get(nombre_destino)
        #si no existen no se puede calcular la ruta
        if not candidatos_origen or not candidatos_destino: return None, None
        #mira si el nodo origen y destino estan en la misma linea
        for u in candidatos_origen:
            linea_u = u.split('_')[-1]
            for v in candidatos_destino:
                linea_v = v.split('_')[-1]
                #si estan en la misma linea se eligen esos nodos como el mejor par
                if linea_u == linea_v: return u, v
        #si no comparten linea, hay que hacer transbordo,se toma el primer candidato de cada lista
        return candidatos_origen[0], candidatos_destino[0]

    def calcular_ruta(self):
        #obtiene el nombre de la estación que se ha puesto en la caja
        origen_nombre = self.combo_origen.get()
        destino_nombre = self.combo_destino.get()
        #si no se ha puesto origen o destino, se detiene el proceso y muestra un mensaje
        if not origen_nombre or not destino_nombre:
            messagebox.showinfo("Error", "Selecciona origen y destino.")
            return
        #obtiene el la mejor pareja
        id_origen, id_destino = self.obtener_mejor_nodo(origen_nombre, destino_nombre)
        #si no se encuentra da error
        if not id_origen or not id_destino:
            messagebox.showerror("Error", "Estación no válida.")
            return
        #usa A* para obtener los nodos de la ruta mas optima y la distancia total
        ruta, costo_metros = self.buscador.encontrar_ruta(id_origen, id_destino)
        #dibuja el mapa
        self.dibujar_mapa()
        #si no se encuentra ruta muestra un mensaje
        if not ruta:
            self.mostrar_info("No se encontró ruta.")
            return

        #contadores de paradas y transbordos
        num_paradas = 0
        num_transbordos = 0
        #selecciona la linea actual(la primera linea)
        linea_actual = ruta[0].split('_')[-1]
        #recorre la ruta
        for i in range(1, len(ruta)):
            linea_nueva = ruta[i].split('_')[-1]
            #si hay un transbordo cambio de linea
            if linea_nueva != linea_actual:
                num_transbordos += 1
                linea_actual = linea_nueva
            else:
                #si no hay transbordo aumento las paradas
                num_paradas += 1
        
        #calcula el tiempo estimado
        tiempo_viaje = (costo_metros / 580) + (num_paradas * 0.5) + (num_transbordos * 4)
        if self.hora_punta_var.get(): tiempo_viaje *= 1.5
        #redondeo(quito decimales)
        tiempo_viaje = int(math.ceil(tiempo_viaje))
        #muestra el tiempo las paradas y los trasbordos
        self.mostrar_pasos_detallados(ruta, costo_metros, tiempo_viaje)
        #hago la animación de la ruta
        self.animar_ruta(ruta, 0)

    #Muestra al usuario la ruta optima del algoritmo,identificando transbordos 
    def mostrar_pasos_detallados(self, ruta, distancia, tiempo):
        #Habilita la escritura y limpia el contenido que hubiese antes
        self.txt_pasos.config(state="normal")
        self.txt_pasos.delete(1.0, tk.END)
        #Muestra el coste y tiempo total
        self.txt_pasos.insert(tk.END, f"⏱ {tiempo} min total  |  📏 {int(distancia)} m\n\n", "titulo")
        #Mira si se activo la opcion de hora punta
        if self.hora_punta_var.get(): self.txt_pasos.insert(tk.END, "⚠ Retrasos por hora punta incluidos\n\n", "alerta")

        #Inicia la ruta
        nodo_inicio = ruta[0]
        nombre_inicio = self.nombres_mapa.get(nodo_inicio, nodo_inicio.split('_')[0])
        linea_actual = nodo_inicio.split('_')[-1]
        #Obtiene la direccion de la primea linea
        dir_str = ""
        if len(ruta) > 1:
            dir_term = self.get_direccion_linea(ruta[0], ruta[1], linea_actual)
            if dir_term: dir_str = f"Dir. {dir_term}"

        #Inserta el punto de salida
        self.txt_pasos.insert(tk.END, f"• Inicio en {nombre_inicio}\n", "pasos")
        if dir_str: self.txt_pasos.insert(tk.END, f"   → {self.info_lineas.get(linea_actual)} ({dir_str})\n", "direccion")
        
        count = 0 #Contador de estacione
        for i in range(1, len(ruta)):
            nodo = ruta[i]
            linea = nodo.split('_')[-1]
            #Mira si hay transbordo
            if linea != linea_actual:
                if count > 0: self.txt_pasos.insert(tk.END, f"   ↓  {count} estaciones\n", "meta")
                nombre_trans = self.nombres_mapa.get(nodo, nodo.split('_')[0])
                if i == 1 and nombre_trans == nombre_inicio:
                    linea_actual = linea
                    if i+1 < len(ruta):
                        dir_term = self.get_direccion_linea(ruta[i], ruta[i+1], linea)
                        if dir_term: self.txt_pasos.insert(tk.END, f"   → Cambio a {self.info_lineas.get(linea)} (Dir. {dir_term})\n", "direccion")
                    continue
                #Imprime el transbordo y la siguiente linea que usa
                self.txt_pasos.insert(tk.END, f"• TRANSBORDO en {nombre_trans}\n", "transbordo")
                if i+1 < len(ruta):
                    dir_term = self.get_direccion_linea(ruta[i], ruta[i+1], linea)
                    if dir_term: self.txt_pasos.insert(tk.END, f"   → {self.info_lineas.get(linea)} (Dir. {dir_term})\n", "direccion")
                linea_actual = linea
                count = 0 #Resetea el contador
            else: count += 1
        
        if count > 0: self.txt_pasos.insert(tk.END, f"   ↓  {count} estaciones\n", "meta")
        nombre_fin = self.nombres_mapa.get(ruta[-1], ruta[-1].split('_')[0])
        self.txt_pasos.insert(tk.END, f"🏁 Llegada a {nombre_fin}", "titulo")
        self.txt_pasos.config(state="disabled")

    #Muestra un mensaje de informacion o error
    def mostrar_info(self, texto):
        #Habilita para poder escribir 
        self.txt_pasos.config(state="normal")
        #Borra contenido previo
        self.txt_pasos.delete(1.0, tk.END)
        #Inserta texto
        self.txt_pasos.insert(tk.END, texto)
        self.txt_pasos.config(state="disabled")

    #Resalta un nodo con un halo para asegurar el centrado
    def resaltar_nodo(self, nodo, color, scale, dx, dy):
        #Verifica que el nodo exista
        if nodo in Placements.COORDS_GUI:
            x_base, y_base = Placements.COORDS_GUI[nodo]
            #aplica la transformacion
            x = x_base * scale + dx
            y = y_base * scale + dy
            r = 9 * scale
            borde = "white"
            #Dibuja el ovalo resaltado
            self.canvas.create_oval(x-r, y-r, x+r, y+r, fill=color, outline=borde, width=2, tags="ruta_animada")

    #Crea un efecto de animacion de la ruta seguida por el usuario
    def animar_ruta(self, ruta, index):
        scale, dx, dy = self.obtener_transformacion()
        #Si llega al penultim nodo para
        if index >= len(ruta) - 1: 
            #Marca el nodo destino de rojo
            self.resaltar_nodo(ruta[-1], "#EF4444", scale, dx, dy) 
            return

        u = ruta[index]
        v = ruta[index+1]
        nombre_u = u.rsplit('_', 1)[0]
        nombre_v = v.rsplit('_', 1)[0]
        
        #Resalta el nodo origen
        if index == 0: self.resaltar_nodo(u, "#3B82F6", scale, dx, dy)
        #Resalta transbordos
        elif nombre_u == nombre_v: self.resaltar_nodo(u, "#FACC15", scale, dx, dy)

        if u in Placements.COORDS_GUI and v in Placements.COORDS_GUI:
            x1_base, y1_base = Placements.COORDS_GUI[u]
            x2_base, y2_base = Placements.COORDS_GUI[v]
            x1 = x1_base * scale + dx
            y1 = y1_base * scale + dy
            x2 = x2_base * scale + dx
            y2 = y2_base * scale + dy
            color = "#22D3EE"#Color de la ruta del ususario
            #Dibuja el segmento de la linea resaltada
            self.canvas.create_line(x1, y1, x2, y2, fill=color, width=5*scale, capstyle=tk.ROUND)
            
        #Llama al siguient segmento  pasados 150ms
        self.root.after(150, lambda: self.animar_ruta(ruta, index + 1))

#EJECUCIÓN PRINCIPAL
if __name__ == "__main__":
    #Crea la ventana princiapl
    root = tk.Tk()
    try:
        from ctypes import windll
        windll.shcore.SetProcessDpiAwareness(1)
    except: pass
    #Instancia  la aplicacion del metro
    app = InterfazMetro2025(root)
    #Inicia el bucle de eventos
    root.mainloop()